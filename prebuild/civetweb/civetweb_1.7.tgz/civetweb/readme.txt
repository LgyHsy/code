编译安装说明
1，设置环境变量 CC 和 CXX 为 交叉编译工具链。
    export CC=arm-sigmastar-linux-uclibcgnueabihf-gcc CXX=arm-sigmastar-linux-uclibcgnueabihf-g++
2，编译静态库，生成的静态库libcivetweb.a在当前目录。
    make lib
3，编译动态库，生成的静态库libcivetweb.so在当前目录。
    make slib
4，设置库的安装路径，环境变量 PREFIX 
 export PREFIX=civetweb/install(替代为实际项目工程的lib路径）
5，安装静态库到系统 
    make install-lib 
6，安装动态库到系统 
    make install-slib 



