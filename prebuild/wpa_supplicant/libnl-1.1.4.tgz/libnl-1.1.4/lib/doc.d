doc.o doc.d : doc.c \
 /media/ken/cdcb6d1d-84ad-4ed6-9ddf-fdca5f59e073/338_sdk/toolchain/gcc-sigmastar-9.1.0-2019.11-x86_64_arm-linux-gnueabihf/arm-linux-gnueabihf/libc/usr/include/stdc-predef.h
