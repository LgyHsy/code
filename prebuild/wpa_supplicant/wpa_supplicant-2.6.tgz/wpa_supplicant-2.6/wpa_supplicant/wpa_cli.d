wpa_cli.o: wpa_cli.c \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/includes.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/build_config.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/cli.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/list.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/wpa_ctrl.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/os.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/wpa_debug.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/wpabuf.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/eloop.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/edit.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/version.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/ieee802_11_defs.h
