notify.o: notify.c \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/includes.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/build_config.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/os.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/wpa_debug.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/wpabuf.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/wpa_ctrl.h \
 config.h config_ssid.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/defs.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/list.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/eap_peer/eap_config.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/wps/wps.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/ieee802_11_defs.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/wps/wps_defs.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/ieee802_11_common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/defs.h \
 wpa_supplicant_i.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/sae.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/wps/wps_defs.h \
 wmm_ac.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/drivers/driver.h \
 wps_supplicant.h binder/binder.h dbus/dbus_common.h dbus/dbus_old.h \
 dbus/dbus_new.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/p2p/p2p.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/rsn_supp/wpa.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/eapol_common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/wpa_common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/fst/fst.h \
 driver_i.h scan.h p2p_supplicant.h sme.h notify.h
