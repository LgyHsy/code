../src/drivers/driver_nl80211_monitor.o: \
 ../src/drivers/driver_nl80211_monitor.c \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/includes.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/build_config.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/os.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/wpa_debug.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/wpabuf.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/eloop.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/ieee802_11_defs.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/ieee802_11_common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/defs.h \
 ../src/drivers/linux_ioctl.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/radiotap_iter.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/radiotap.h \
 ../src/drivers/driver_nl80211.h ../src/drivers/nl80211_copy.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/list.h \
 ../src/drivers/driver.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/defs.h
