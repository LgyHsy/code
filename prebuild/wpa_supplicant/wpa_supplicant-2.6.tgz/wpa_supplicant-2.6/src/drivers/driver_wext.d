../src/drivers/driver_wext.o: ../src/drivers/driver_wext.c \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/includes.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/build_config.h \
 ../src/drivers/linux_wext.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/os.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/wpa_debug.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/wpabuf.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/eloop.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/ieee802_11_defs.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/wpa_common.h \
 ../src/drivers/priv_netlink.h ../src/drivers/netlink.h \
 ../src/drivers/linux_ioctl.h ../src/drivers/rfkill.h \
 ../src/drivers/driver.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/defs.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/list.h \
 ../src/drivers/driver_wext.h
