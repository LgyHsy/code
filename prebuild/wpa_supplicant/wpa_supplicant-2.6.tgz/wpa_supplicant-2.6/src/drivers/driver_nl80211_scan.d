../src/drivers/driver_nl80211_scan.o: \
 ../src/drivers/driver_nl80211_scan.c \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/includes.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/build_config.h \
 /opt/libnl/include/netlink/genl/genl.h \
 /opt/libnl/include/netlink/netlink.h \
 /opt/libnl/include/netlink/netlink-compat.h \
 /opt/libnl/include/netlink/types.h /opt/libnl/include/netlink/handlers.h \
 /opt/libnl/include/netlink/netlink-kernel.h \
 /opt/libnl/include/netlink/socket.h /opt/libnl/include/netlink/msg.h \
 /opt/libnl/include/netlink/object.h /opt/libnl/include/netlink/utils.h \
 /opt/libnl/include/netlink/list.h /opt/libnl/include/netlink/attr.h \
 /opt/libnl/include/netlink/addr.h /opt/libnl/include/netlink/data.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/os.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/wpa_debug.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/wpabuf.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/eloop.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/ieee802_11_defs.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/ieee802_11_common.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/defs.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/qca-vendor.h \
 ../src/drivers/driver_nl80211.h ../src/drivers/nl80211_copy.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/utils/list.h \
 ../src/drivers/driver.h \
 /media/ken/bdbe47e9-af62-495d-ad7a-064a7a79213f/home/wpa_supplicant_atbm6032/wpa_supplicant/wpa_supplicant-2.6/src/common/defs.h
