#!/bin/bash

export ZXING_DIR=$PWD
export OSDRV_DIR=$PWD/../../code/
export BUILD_ROOT_DIR=$PWD/../../build/ftp
export LIB_ROOT_DIR=$PWD/../../code/lib

env_array[0]="setenv_msr620q"
env_array[1]="setenv_mstar_i5"
env_array[2]="setenv_mstar"
env_array[3]="setenv_hi3516ad"
env_array[3]="setenv_hi35xx"
env_array[4]="setenv_hi3518ev200"
env_array[5]="setenv_hi3516cv300"
env_array[6]="setenv_ambar_s2lm2"
env_array[7]="setenv_ambar_s2l_v2.5"
#env_array[8]="setenv_ambar_s2l"
#env_array[9]="setenv_dm36x"
#env_array[10]="setenv_ambar_s2lm"

compile_array[0]="arm-buildroot-linux-uclibcgnueabi"
compile_array[1]="arm-buildroot-linux-uclibcgnueabihf"
compile_array[2]="arm-linux-gnueabihf"
compile_array[3]="arm-hisiv300-linux"
compile_array[3]="arm-hisiv100nptl-linux"
compile_array[4]="arm-hisiv300-linux"
compile_array[5]="arm-hisiv500-linux"
compile_array[6]="arm-linux-gnueabihf"
compile_array[7]="arm-linux-gnueabihf"
compile_array[8]="arm-ambarella-linux-uclibcgnueabihf"
compile_array[9]="arm-linux-gnueabihf"
compile_array[10]="arm_v5t_le"

a_len=${#env_array[@]}
a_len=2
export INDEX_FROM=0
export INDEX_END=$a_len

if [ TEST$1 != "TEST" ];
then 
	INDEX_FROM=$1
	
	if [ $INDEX_FROM -ge $a_len ];
	then 
		INDEX_FROM=0
	fi	
fi

if [ TEST$2 != "TEST" ];
then 
	INDEX_END=$2
	
	if [ $INDEX_END -ge $a_len ];
	then 
		INDEX_END=$a_len
	fi	
	
	if [ $INDEX_END -le $INDEX_FROM ];
	then 
		INDEX_END=$a_len
#		let INDEX_END=1+INDEX_FROM 
	fi	
fi

echo "from $INDEX_FROM -> $INDEX_END"


echo "env number $a_len"
for((count=$INDEX_FROM,i=$INDEX_FROM;count<$INDEX_END;i++))
do
    echo $i : ${env_array[$i]} 
    	
    cd $OSDRV_DIR
    source ${env_array[$i]}

		export CC="${compile_array[$i]}"-gcc
		export CXX="${compile_array[$i]}"-g++
		export AR="${compile_array[$i]}"-ar
		export LD="${compile_array[$i]}"-ld
		export LDXX="${compile_array[$i]}"-g++
		export RANLIB="${compile_array[$i]}"-ranlib
		export STRIP="${compile_array[$i]}"-strip
		
		echo "######################$CC##############################"

		cd $ZXING_DIR
    
		./configure --prefix=/tmp/lame --host="${compile_array[$i]}"  --with-pic
		make clean 
		make
    
   	cp ./frontend/lame /ftp/mstar/
   	cp ./libmp3lame/.libs/libmp3lame.a $LIB_ROOT_DIR/$PLATFORM
 	
   	make clean
   	
    let count+=1 
    
done
